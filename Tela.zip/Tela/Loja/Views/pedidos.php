<?php
session_start();

// Mostrar erros (apenas no ambiente de desenvolvimento)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../config/db.php';

// Consulta os produtos (caso necessário no futuro)
$stmt = $conn->prepare("SELECT * FROM produtos");
$stmt->execute();
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Consulta os pedidos
$stmt = $conn->prepare("
    SELECT 
        pedidos.id, pedidos.quantidade, pedidos.subtotal, pedidos.frete, pedidos.cep, pedidos.status, pedidos.created_at,
        produtos.nome
    FROM pedidos
    JOIN produtos ON pedidos.produto_id = produtos.id
    ORDER BY pedidos.created_at DESC
");
$stmt->execute();
$pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Mensagens de sessão
$message = $_SESSION['message'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['message'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8"/>
    <title>Pedidos</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f9f9f9;}
        .container { max-width: 1000px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc;}
        h1 { text-align: center; margin-bottom: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background-color: #f7f7f7; }
        .status-pendente { color: orange; font-weight: bold; }
        .status-concluido { color: green; font-weight: bold; }
        .status-cancelado { color: red; font-weight: bold; }
        .message { color: green; font-weight: bold; margin-bottom: 10px; }
        .error { color: red; font-weight: bold; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Pedidos</h1>

        <?php if ($message): ?>
            <p class="message"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <?php if (count($pedidos) === 0): ?>
            <p>Nenhum pedido encontrado.</p>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Subtotal (R$)</th>
                    <th>Frete (R$)</th>
                    <th>CEP</th>
                    <th>Status</th>
                    <th>Criado em</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pedidos as $pedido): ?>
                <tr>
                    <td><?= htmlspecialchars($pedido['id']) ?></td>
                    <td><?= htmlspecialchars($pedido['nome']) ?></td>
                    <td><?= htmlspecialchars($pedido['quantidade']) ?></td>
                    <td><?= number_format($pedido['subtotal'], 2, ',', '.') ?></td>
                    <td><?= number_format($pedido['frete'], 2, ',', '.') ?></td>
                    <td><?= htmlspecialchars($pedido['cep']) ?></td>
                    <td class="status-<?= htmlspecialchars($pedido['status']) ?>">
                        <?= htmlspecialchars(ucfirst($pedido['status'])) ?>
                    </td>
                    <td><?= htmlspecialchars($pedido['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</body>
</html>
