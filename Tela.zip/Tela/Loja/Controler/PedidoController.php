<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../models/Pedido.php';
require_once __DIR__ . '/../models/Produto.php';

$produtoModel = new Produto(db: $conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifica se é requisição para compra
    if (isset($_POST['comprar'])) {
        $produto_id = intval($_POST['produto_id'] ?? 0);
        $quantidade = intval($_POST['quantidade'] ?? 0);
        $cep = trim($_POST['cep'] ?? '');

        if ($produto_id <= 0 || $quantidade <= 0) {
            $_SESSION['error'] = "Produto ou quantidade inválidos.";
            header('Location: ../views/produtos.php');
            exit;
        }

        // Validar CEP básico (pode expandir para usar API ViaCEP se desejar)
        if (!preg_match('/^\d{5}-?\d{3}$/', $cep)) {
            $_SESSION['error'] = "CEP inválido. Informe no formato 00000-000.";
            header('Location: ../views/produtos.php');
            exit;
        }

        $produto = $produtoModel->getById($produto_id);
        if (!$produto) {
            $_SESSION['error'] = "Produto não encontrado.";
            header('Location: ../views/produtos.php');
            exit;
        }

        $estoque = $produto['quantidade'] ?? 0;
        if ($estoque < $quantidade) {
            $_SESSION['error'] = "Estoque insuficiente para o pedido.";
            header('Location: ../views/produtos.php');
            exit;
        }

        $subtotal = $produto['preco'] * $quantidade;
        $frete = calcularFrete($subtotal);

        // Atualizar estoque
        $produtoModel->updateEstoque($produto_id, $estoque - $quantidade);

        // Criar pedido no banco de dados
        $pedidoModel->create($produto_id, $quantidade, $subtotal, $frete, $cep);

        // TODO: implemente envio de e-mail com dados do pedido aqui

        $_SESSION['message'] = "Pedido realizado com sucesso!";
        header('Location: ../views/produtos.php');
        exit;
    }
}

// Função para calcular o valor do frete conforme regras do enunciado
function calcularFrete(float $subtotal): float {
    if ($subtotal >= 52 && $subtotal <= 166.59) {
        return 15.00;
    } elseif ($subtotal > 200) {
        return 0.00;
    } else {
        return 20.00;
    }
}

// Webhook para atualização do status do pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['webhook'])) {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['id']) || !isset($input['status'])) {
        http_response_code(400);
        echo json_encode(['message' => 'Parâmetros id e status são obrigatórios.']);
        exit;
    }

    $id = intval($input['id']);
    $status = $input['status'];

    if ($status === 'cancelado') {
        $pedidoModel->delete($id);
        echo json_encode(['message' => 'Pedido removido.']);
    } else {
        $pedidoModel->updateStatus($id, $status);
        echo json_encode(['message' => 'Status do pedido atualizado.']);
    }
    exit;
}
?>
