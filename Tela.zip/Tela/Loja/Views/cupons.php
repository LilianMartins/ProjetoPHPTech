<?php
require_once __DIR__ . '/../config/db.php';
require_once("../Model/Cupom.php");

$db = (new Database())->getConnection();
$cupom = new Cupom($db);

// ... seu código usando $cupom
