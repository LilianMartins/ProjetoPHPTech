<?php
// Página inicial simples, com links para as seções principais do sistema
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Loja - Sistema</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background:#f5f5f5; }
        .container { max-width: 600px; margin: auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); text-align: center;}
        h1 { margin-bottom: 30px; }
        a { display: inline-block; margin: 15px 10px; padding: 15px 25px; background: #007bff; color: white; border-radius: 5px; text-decoration: none; font-size: 18px; }
        a:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bem-vindo ao Sistema da Loja</h1>
        <a href="Views/produtos.php">Gerenciar Produtos</a>
        <a href="Views/pedidos.php">Visualizar Pedidos</a>
        <a href="Views/cupons.php">Gerenciar Cupons</a>
    </div>
</body>
</html>
