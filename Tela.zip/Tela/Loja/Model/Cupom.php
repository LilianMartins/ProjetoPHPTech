<?php


class Cupom {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($codigo, $validade, $valor_minimo, $desconto) {
        $stmt = $this->conn->prepare("INSERT INTO cupons (codigo, validade, valor_minimo, desconto) VALUES (?, ?, ?, ?)");
        $stmt->execute([$codigo, $validade, $valor_minimo, $desconto]);
    }

    public function getByCodigo($codigo) {
        $stmt = $this->conn->prepare("SELECT * FROM cupons WHERE codigo = ?");
        $stmt->execute([$codigo]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM cupons ORDER BY created_at DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
