
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../models/Produto.php';
$produtoModel = new Produto($conn);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $nome = trim($_POST['nome']);
    $preco = floatval($_POST['preco']);
    $variacoes = $_POST['variacoes'] ?? '{}'; // JSON string das variações
    $quantidade = intval($_POST['quantidade']);
    if ($id) {
        // Update
        $produtoModel->update($id, $nome, $preco, $variacoes, $quantidade);
        $_SESSION['message'] = "Produto atualizado com sucesso.";
    } else {
        // Create
        $produtoModel->create($nome, $preco, $variacoes, $quantidade);
        $_SESSION['message'] = "Produto criado com sucesso.";
    }
    header("Location: ../views/produtos.php");
    exit;
}
?>