<?php
class Produto {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($nome, $preco, $variacoes, $quantidade) {
        $stmt = $this->conn->prepare("INSERT INTO produtos (nome, preco, variacoes) VALUES (?, ?, ?)");
        $stmt->execute([$nome, $preco, $variacoes]);
        $produto_id = $this->conn->lastInsertId();

        $stmt = $this->conn->prepare("INSERT INTO estoque (produto_id, quantidade) VALUES (?, ?)");
        $stmt->execute([$produto_id, $quantidade]);
    }

    public function update($id, $nome, $preco, $variacoes, $quantidade) {
        $stmt = $this->conn->prepare("UPDATE produtos SET nome = ?, preco = ?, variacoes = ? WHERE id = ?");
        $stmt->execute([$nome, $preco, $variacoes, $id]);

        $stmt = $this->conn->prepare("UPDATE estoque SET quantidade = ? WHERE produto_id = ?");
        $stmt->execute([$quantidade, $id]);
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT p.*, e.quantidade FROM produtos p JOIN estoque e ON p.id = e.produto_id");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT p.*, e.quantidade FROM produtos p JOIN estoque e ON p.id = e.produto_id WHERE p.id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    
    public function getEstoque($produto_id) {
        $stmt = $this->conn->prepare("SELECT quantidade FROM estoque WHERE produto_id = ?");
        $stmt->execute([$produto_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? intval($result['quantidade']) : 0;
    }

    public function updateEstoque($produto_id, $quantidade) {
        $stmt = $this->conn->prepare("UPDATE estoque SET quantidade = ? WHERE produto_id = ?");
        $stmt->execute([$quantidade, $produto_id]);
    }
}
?>
